#!/usr/bin/env python3
"""Helper script to prepend a progression entry to CHANGELOG.md and auto-commit it."""

import argparse
from datetime import datetime, timezone, timedelta
from pathlib import Path
import subprocess
import sys


HEADER_BLOCK = """# Changelog

All notable commit-by-commit progressions for this project are documented in this file (most recent first).

---
"""


def run_git(args: list[str]) -> str | None:
    try:
        res = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            check=True,
        )
        return res.stdout.strip()
    except subprocess.CalledProcessError:
        return None


def is_changelog_commit(ref: str, changelog_relpath: str = "CHANGELOG.md") -> bool:
    subject = run_git(["log", "-1", "--format=%s", ref]) or ""
    if subject.lower().startswith(("docs(changelog):", "chore(changelog):")):
        return True
    changed_files = run_git(["diff-tree", "--no-commit-id", "--name-only", "-r", ref])
    if changed_files and changed_files.splitlines() == [changelog_relpath]:
        return True
    return False


def resolve_git_metadata(changelog_relpath: str = "CHANGELOG.md") -> tuple[str, str, str, str]:
    """Resolve (old_commit_hash, old_changelog_hash, new_commit_hash, commit_message) after <new_commit> is created."""
    new_hash = run_git(["rev-parse", "--short=7", "HEAD"])
    if not new_hash:
        raise RuntimeError("No commits found in repository; create <new_commit> before running with --from-git.")

    message = run_git(["log", "-1", "--format=%s", "HEAD"]) or ""
    parent_hash = run_git(["rev-parse", "--short=7", "HEAD~1"])

    if not parent_hash:
        return ("None (Initial Commit)", "", new_hash, message)

    if is_changelog_commit("HEAD~1", changelog_relpath):
        grandparent_hash = run_git(["rev-parse", "--short=7", "HEAD~2"])
        if grandparent_hash:
            return (grandparent_hash, parent_hash, new_hash, message)

    return (parent_hash, "", new_hash, message)


def get_ist_timestamp() -> str:
    ist = timezone(timedelta(hours=5, minutes=30))
    return datetime.now(ist).strftime("%Y-%m-%d %H:%M:%S IST")


DEFAULT_KEYLOG_DIR = (
    Path("/home/sanjay/Desktop/sanjay/brain-storming/new-skill/setup/Keylogger/linux")
    if Path("/home/sanjay/Desktop/sanjay/brain-storming/new-skill/setup/Keylogger/linux").exists()
    else Path("/home/sanjay/Desktop/sanjay/brain-storming/new-skill/Keylogger/linux")
)
DEFAULT_GITHUB_REMOTE_URL = "https://github.com/SOCS-Elite-WR-2027/24BCT044.git"


def find_latest_keylog(keylog_dir: Path) -> Path | None:
    """Return the most recently modified .log file in keylog_dir."""
    if not keylog_dir.exists() or not keylog_dir.is_dir():
        return None
    log_files = sorted(
        keylog_dir.glob("*.log"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return log_files[0] if log_files else None


def replay_keystrokes(raw_line: str) -> str:
    """Apply backspace (\x08) characters and strip non-printable/modifier artifacts."""
    buf: list[str] = []
    for ch in raw_line:
        if ch == "\x08":
            if buf:
                buf.pop()
        elif 32 <= ord(ch) <= 126:
            buf.append(ch)
    return "".join(buf).strip()


def parse_keylog_file(log_path: Path) -> list[str]:
    """Parse raw keylogger file into reconstructed lines/commands."""
    raw_bytes = log_path.read_bytes()
    raw_text = raw_bytes.decode("utf-8", errors="replace")
    segments = [seg for chunk in raw_text.splitlines() for seg in chunk.split("\r")]
    cleaned: list[str] = []
    for seg in segments:
        replayed = replay_keystrokes(seg)
        if replayed:
            cleaned.append(replayed)
    return cleaned


def build_keylog_report_block(
    log_path: Path | None,
    comparison_notes: list[str],
    changed_files: list[str],
) -> str:
    """Build a simple 2-3 line Keylogger Report section comparing the latest keylog file with the commit."""
    if not log_path and not comparison_notes:
        return ""

    report_lines: list[str] = []
    if comparison_notes:
        report_lines = [note.lstrip("- ").strip() for note in comparison_notes[:3]]
    elif log_path and log_path.exists():
        parsed_events = parse_keylog_file(log_path)
        events_preview = ", ".join(parsed_events[:6]) if parsed_events else "no printable events"
        files_preview = ", ".join(changed_files) if changed_files else "staged files"
        report_lines = [
            f"Compared latest keylog `{log_path.name}` against committed changes in `{files_preview}`.",
            f"Recorded keystrokes ({events_preview}) match the file creation, edits, and Git staging commands.",
        ]

    body = "\n".join(report_lines[:3])
    return f"### Keylogger Report\n{body}\n\n"


def format_entry(
    old_hash: str,
    old_changelog_hash: str,
    new_hash: str,
    timestamp: str,
    message: str,
    summary_lines: list[str],
    keylog_block: str = "",
) -> str:
    summary_block = "\n".join(summary_lines)
    if old_changelog_hash and old_changelog_hash.lower() != "none":
        progression_str = f"`{old_hash}` --> `{old_changelog_hash}` --> `{new_hash}`"
        old_commit_line = f"- **Old Commit Hash**: `{old_hash}` (changelog commit: `{old_changelog_hash}`)"
    else:
        progression_str = f"`{old_hash}` --> `{new_hash}`"
        old_commit_line = f"- **Old Commit Hash**: `{old_hash}`"

    return (
        f"\n## [{new_hash}] - {timestamp}\n\n"
        f"- **Progression**: {progression_str}\n"
        f"{old_commit_line}\n"
        f"- **New Commit Hash**: `{new_hash}`\n"
        f"- **Timestamp (IST)**: `{timestamp}`\n"
        f"- **Commit Message**: `{message}`\n\n"
        f"### Progression Summary\n"
        f"{summary_block}\n\n"
        f"{keylog_block}"
        f"---\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Prepend a commit progression section to CHANGELOG.md and optionally auto-commit it."
    )
    parser.add_argument(
        "--changelog",
        default="CHANGELOG.md",
        help="Path to CHANGELOG.md (default: CHANGELOG.md)",
    )
    parser.add_argument(
        "--from-git",
        action="store_true",
        help="Automatically resolve old_commit_a, old_changelog_commit_a, new_commit, and message from Git history",
    )
    parser.add_argument(
        "--old-hash",
        default="",
        help="Previous primary commit hash (<old_commit_a> or 'None (Initial Commit)')",
    )
    parser.add_argument(
        "--old-changelog-hash",
        default="",
        help="Previous automatic changelog commit hash (<old_changelog_commit_a>, optional)",
    )
    parser.add_argument(
        "--new-hash",
        default="",
        help="Newly created primary commit hash (<new_commit>)",
    )
    parser.add_argument(
        "--timestamp",
        default="",
        help="Timestamp in IST (defaults to current time in IST)",
    )
    parser.add_argument(
        "--message",
        default="",
        help="Commit message provided by the user",
    )
    parser.add_argument(
        "--summary",
        required=True,
        help="3-4 line summary of the project progression",
    )
    parser.add_argument(
        "--auto-commit",
        action="store_true",
        help="Automatically stage CHANGELOG.md and create a separate changelog commit",
    )
    parser.add_argument(
        "--keylog-dir",
        default=str(DEFAULT_KEYLOG_DIR),
        help="Directory to scan for the latest keylogger .log file",
    )
    parser.add_argument(
        "--keylog-file",
        default="",
        help="Explicit path to a keylogger .log file to compare against",
    )
    parser.add_argument(
        "--keylog-comparison",
        default="",
        help="Newline-separated comparison notes correlating the latest keylog file with the committed changes",
    )
    parser.add_argument(
        "--no-keylog",
        action="store_true",
        help="Skip attaching the keylogger comparison report section",
    )
    parser.add_argument(
        "--auto-push",
        action="store_true",
        help="Automatically push the primary commit and CHANGELOG.md commit to the GitHub remote",
    )
    parser.add_argument(
        "--remote",
        default="origin",
        help="Git remote name or URL to push to (default: origin)",
    )
    parser.add_argument(
        "--branch",
        default="",
        help="Target branch to push (defaults to current active branch)",
    )

    args = parser.parse_args()

    summary_lines = [
        line.strip() for line in args.summary.strip().splitlines() if line.strip()
    ]
    if not (1 <= len(summary_lines) <= 4):
        print(
            f"Error: Progression summary must be at most 3-4 lines (got {len(summary_lines)} lines).",
            file=sys.stderr,
        )
        return 1

    if args.from_git:
        old_hash, old_changelog_hash, new_hash, git_message = resolve_git_metadata(args.changelog)
        message = args.message.strip() or git_message
    else:
        if not (args.old_hash and args.new_hash and args.message):
            print(
                "Error: Either pass --from-git or provide --old-hash, --new-hash, and --message.",
                file=sys.stderr,
            )
            return 1
        old_hash = args.old_hash.strip()
        old_changelog_hash = args.old_changelog_hash.strip()
        new_hash = args.new_hash.strip()
        message = args.message.strip()

    keylog_block = ""
    if not args.no_keylog:
        log_path = (
            Path(args.keylog_file)
            if args.keylog_file.strip()
            else find_latest_keylog(Path(args.keylog_dir))
        )
        comparison_notes = [
            line.strip()
            for line in args.keylog_comparison.strip().splitlines()
            if line.strip()
        ]
        if comparison_notes and len(comparison_notes) > 3:
            print(
                f"Error: Keylogger report summary must be at most 2-3 lines (got {len(comparison_notes)} lines).",
                file=sys.stderr,
            )
            return 1
        changed_raw = run_git(["diff-tree", "--root", "--no-commit-id", "--name-only", "-r", "HEAD"]) or ""
        changed_files = [f.strip() for f in changed_raw.splitlines() if f.strip()]
        keylog_block = build_keylog_report_block(
            log_path=log_path,
            comparison_notes=comparison_notes,
            changed_files=changed_files,
        )

    timestamp = args.timestamp.strip() or get_ist_timestamp()
    entry = format_entry(
        old_hash=old_hash,
        old_changelog_hash=old_changelog_hash,
        new_hash=new_hash,
        timestamp=timestamp,
        message=message,
        summary_lines=summary_lines,
        keylog_block=keylog_block,
    )

    changelog_path = Path(args.changelog)
    if not changelog_path.exists():
        new_content = HEADER_BLOCK + entry
    else:
        existing = changelog_path.read_text(encoding="utf-8")
        marker = "\n---\n"
        if existing.startswith("# Changelog") and marker in existing:
            idx = existing.index(marker) + len(marker)
            new_content = existing[:idx] + entry + existing[idx:]
        elif existing.startswith("# Changelog"):
            lines = existing.splitlines(keepends=True)
            new_content = lines[0] + "\n---\n" + entry + "".join(lines[1:])
        else:
            new_content = HEADER_BLOCK + entry + "\n" + existing

    changelog_path.write_text(new_content, encoding="utf-8")
    chain_label = (
        f"{old_hash} --> {old_changelog_hash} --> {new_hash}"
        if old_changelog_hash and old_changelog_hash.lower() != "none"
        else f"{old_hash} --> {new_hash}"
    )
    print(f"Successfully prepended progression [{chain_label}] to {changelog_path}")

    if args.auto_commit:
        subprocess.run(["git", "add", str(changelog_path)], check=True)
        commit_msg = f"docs(changelog): record progression for {new_hash}"
        subprocess.run(["git", "commit", "-m", commit_msg], check=True)
        changelog_commit_hash = run_git(["rev-parse", "--short=7", "HEAD"])
        print(f"Created separate changelog commit [{changelog_commit_hash}]: {commit_msg}")

    if args.auto_push:
        remote = args.remote.strip() or "origin"
        existing_remotes = (run_git(["remote"]) or "").splitlines()
        if remote not in existing_remotes and not remote.startswith(("http://", "https://", "git@")):
            subprocess.run(["git", "remote", "add", remote, DEFAULT_GITHUB_REMOTE_URL], check=True)
        branch = args.branch.strip() or (run_git(["rev-parse", "--abbrev-ref", "HEAD"]) or "master")
        subprocess.run(["git", "push", "-u", remote, branch], check=True)
        print(f"Pushed commits and keylogger report in {changelog_path} to {remote}/{branch}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
