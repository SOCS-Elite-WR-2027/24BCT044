# Linux keylogger

This directory contains a Python program that uses `pyxhook` to observe keyboard events across the desktop and write characters to a timestamped log file. System-wide input capture can expose passwords and other private information. Do not use it on another person's device or account, or without explicit informed consent.

For safety, this README does not provide instructions for starting, hiding, or running the logger. For learning Python keyboard events, use a small visible application that only receives text entered into its own input field.

## Notes on the terminal output

- In the current project tree, the Linux files are under `setup/Keylogger/linux`. The path shown in the terminal transcript (`Keylogger/linux`) does not match that location.
- `Keyogger` is a spelling error; the directory is named `Keylogger`.
- The activation path `demoenvbin/activate` is missing a slash between `demoenv` and `bin`.
- Although the prompt shows `(demoenv)`, `which python` points to `/home/sanjay/Desktop/SAMPLE-KEY/demoenv/bin/python`, not this project's `setup/demoenv`. A virtual environment should not be copied or moved between locations; the prompt name alone does not confirm which interpreter is active.
- The `FileNotFoundError` occurs when the event callback tries to open the timestamped log path. It indicates that the requested path could not be opened; check the actual working directory and whether the destination directory exists and is writable. The transcript alone does not establish which of these caused it.
- `Tkinter is working!` and the presence of `pyxhook` only confirm that those imports are available. They do not confirm that system-wide input capture is safe or appropriate.

## Safer learning alternative

Use a visible form or text-entry widget and handle only text entered directly into that widget. This keeps input within the application and avoids capturing unrelated activity.
